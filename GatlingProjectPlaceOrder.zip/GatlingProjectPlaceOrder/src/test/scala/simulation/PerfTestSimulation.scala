package simulation

import config.BaseHelpers._
import io.gatling.core.Predef._
import io.gatling.http.Predef.http
import scenarios.rampUsers._



class PerfTestSimulation extends Simulation {

  val httpConf = http.baseUrl("http://localhost/checkout")
    .header(name = "Authorization", value = "")


  val csvFeeder = csv("./src/test/resources/feeders/data.csv").circular

  def getDetails() = {
    repeat(2) {
      feed(csvFeeder)
        .exec(http("Get Details")
          .get(s"http://localhost/checkout"))

    }
  }

  val scn1 = scenario("CSV Data").exec(getDetails())
  setUp(

    scnAddCartTable.inject(atOnceUsers(System.getProperty("addTableCart", "1").toInt)),
    scnAddChairCart1.inject(atOnceUsers(System.getProperty("addChairCart", "1").toInt)),
    scnCheckOutItems1.inject(atOnceUsers(System.getProperty("checkoutItems", "1").toInt)),
    scnPercentages.inject(atOnceUsers(System.getProperty("percent", "1").toInt))

  ).protocols(httpProtocol)
}


