package scenarios

  import config.BaseHelpers.{localhostApp, thinkTimer}
  import io.gatling.core.Predef._
  import io.gatling.core.structure._
  import io.gatling.http.Predef._

  import java.awt.Choice

object rampUsers {
  def scnAddCartTable: ScenarioBuilder = {
    scenario("add table to cart")
      .exec(flushHttpCache)
      .exec(flushCookieJar)
      .exitBlockOnFail(
        group("homepage") {
          exec(api.home.blazeHome())
            .exec(thinkTimer())
        }
          .group("tables") {
            exec(api.tables.secondpage())
              .exec(thinkTimer())
          }
          .group("table selection") {
            exec(api.tableselection.tableselection())
              .exec(thinkTimer())
          }
          .group("tableAddedTocart") {
            exec(api.addtabletocart.addtable())
              .exec(thinkTimer())
          }
      )
  }

  def scnAddChairCart1: ScenarioBuilder = {
    scenario("adding chair to cart")
      .exec(flushHttpCache)
      .exec(flushCookieJar)
      .exitBlockOnFail(
        group("select random chair") {
          exec(api.randomchair.selectchair())
            .exec(thinkTimer())
        }
          .group("add chair to cart") {
            exec(api.addchairtocart.addchair())
              .exec(thinkTimer())
          }
      )
  }

  def scnCheckOutItems1: ScenarioBuilder = {
    scenario("CheckOut")
      .exec(flushHttpCache)
      .exec(flushCookieJar)
      .exitBlockOnFail(
        group("open_cart") {
          exec(api.opencart.cart())
            .exec(thinkTimer())
        }
          .group("checkout") {
            exec(api.checkout.checkout())
              .exec(thinkTimer())
          }

      )
  }

  def scnPercentages: ScenarioBuilder = {
    scenario("percentile")
      .exec(flushHttpCache)
      .exec(flushCookieJar)
      .randomSwitch(
        50.0 -> exec(rampUsers.scnAddChairCart1),
        30.0 -> exec(rampUsers.scnCheckOutItems1)
    )
  }
}


