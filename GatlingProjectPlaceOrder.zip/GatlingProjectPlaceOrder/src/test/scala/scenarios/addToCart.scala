package scenarios

import config.BaseHelpers.thinkTimer
import io.gatling.core.Predef._
import io.gatling.core.structure._
import io.gatling.http.Predef._

object addToCart {
  def scnLocalhostDesc: ScenarioBuilder =
  {
    scenario("add items to cart")
      .exec(flushHttpCache)
      .exec(flushCookieJar)
      .exitBlockOnFail(
        group("homepage") {
          exec(api.home.blazeHome())
            .exec(thinkTimer())
        }
          .group("tables subcategory"){
            exec(api.tables.secondpage())
              .exec(thinkTimer())
          }
          .group("table selection"){
            exec(api.tableselection.tableselection())
              .exec(thinkTimer())
          }
          .group("add table to cart"){
            exec(api.addtabletocart.addtable())
              .exec(thinkTimer())
          }
         .group("select random chair"){
            exec(api.randomchair.selectchair())
              .exec(thinkTimer())
          }
          .group("add chair to cart"){
            exec(api.addchairtocart.addchair())
              .exec(thinkTimer())
          }
          .group("checkout"){
            exec(api.checkout.checkout())
              .exec(thinkTimer())
          }
          .group("open cart"){
            exec(api.opencart.cart())
              .exec(thinkTimer())
          }
      )
  }
}
