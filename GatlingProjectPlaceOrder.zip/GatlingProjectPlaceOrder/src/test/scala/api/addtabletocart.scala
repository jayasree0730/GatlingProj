package api

import config.BaseHelpers.localhostApp
import io.gatling.core.structure._
import io.gatling.http.Predef._
import io.gatling.core.Predef._

object addtabletocart
{
  def addtable(cat: String = "Tables"): ChainBuilder = {
    exec(
      http("add table to cart")
       .post( localhostApp + "products-category/tables-2")
       .body(StringBody("""("action":"ic_add_to_cart")"""))
    )
  }
}
